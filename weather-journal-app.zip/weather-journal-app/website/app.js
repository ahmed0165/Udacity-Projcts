/* Global Variables */
const Url = 'http://api.openweathermap.org/data/2.5/forecast?zip=';
// Create a new date instance dynamically with JS
let d = new Date();
let newDate = d.getMonth()+1+'/'+ d.getDate()+'/'+ d.getFullYear();
// Personal API Key for OpenWeatherMap API
const apiKey = ',&appid=a04707d6e0b5a7bd70156a4b863c6f3f&units=metric'; 
// Event listener to add function to existing HTML DOM element
document.getElementById('generate').addEventListener('click',function (event){
    const zip = document.querySelector('#zip').value;
    const userFeelings = document.querySelector('#feelings').value;
    /* Function to GET Web API Data*/
    async function getApi(Url, zipCode, apiKey) {
        const res = await fetch(Url + zipCode + apiKey);
        try {
        const apiData = await res.json();
        return apiData;
        } catch (error) {
            console.log("error", error);
        }
    }
    getApi(Url,zip,apiKey)
    //chain another Promise that makes a POST request to add the API data
    .then((data) => {
        postData('/add', { date: newDate , content: userFeelings , temp : data.list[1].main.temp });
    }).then( ()=> {
        retreiveData();
    })
});

/* Function to POST data */
async function postData(url = '', data = {}) {
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'content-Type': 'application/json' },
        body: JSON.stringify(data),
    });
    try {
        const newData = await response.json();
        return newData;
    } catch (error) {
        console.log('error', error);
    }
}

/* Function to write project data on the client side */
async function retreiveData() {
    const req = await fetch('/all');
    try {
        const Data = await req.json();
        document.querySelector('#temp').innerHTML =Data.temp+ ' degrees';
        document.querySelector('#content').innerHTML = Data.content;
        document.querySelector('#date').innerHTML = Data.date;

    } catch (error) {
        console.log("error", error);
    }
}
//with the help of udacity web class