# Weather-Journal App Project

## description:
weather jornal app with api built by html and css and java script
build aserver with node 
get and post route
acuire api credential from apen weathermap website
build async and await fuction with promises
# author:ahmed medhat
# techs:
1-html 5
2-css3
3-ES6
4-node js
## with the help of udacity web class